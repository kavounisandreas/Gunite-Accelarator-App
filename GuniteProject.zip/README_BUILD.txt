GUNITE ACCELERATOR – ANDROID APP

Έτοιμο Android Studio project.
Package / Application ID: gr.aktor.gunitecalc
Version: 1.0.0
minSdk: 23
targetSdk: 36
compileSdk: 36
Java: 17
Android Gradle Plugin: 9.3.0

ΛΕΙΤΟΥΡΓΙΑ
- Πλήρως offline.
- Δεν απαιτεί Internet permission.
- Οι τύποι του Excel είναι ενσωματωμένοι στο app.
- Οι τελευταίες τιμές αποθηκεύονται τοπικά στο WebView/localStorage.
- Native Android sharing για τα αποτελέσματα.
- Δύο υπολογιστές:
  1. Ρυθμός κατανάλωσης επιταχυντή (L/min)
  2. Πραγματική κατανάλωση από στάθμη δεξαμενής (% κ.β. τσιμέντου)

ΠΑΡΑΓΩΓΗ APK ΣΕ ANDROID STUDIO
1. Αποσυμπίεσε το project.
2. Android Studio > Open > επίλεξε τον φάκελο GuniteAcceleratorAndroid.
3. Εγκατέστησε Android SDK Platform 36 και Build Tools 36.x αν ζητηθούν.
4. Χρησιμοποίησε JDK 17.
5. Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. Το debug APK θα δημιουργηθεί στο:
   app/build/outputs/apk/debug/app-debug.apk

ΓΙΑ RELEASE APK / PLAY STORE
Android Studio > Build > Generate Signed App Bundle / APK.
Θα χρειαστεί keystore που ανήκει στον τελικό εκδότη της εφαρμογής.

ΣΗΜΕΙΩΣΗ
Το project έχει δομηθεί ώστε να μην εξαρτάται από εξωτερικά libraries κατά την εκτέλεση.
